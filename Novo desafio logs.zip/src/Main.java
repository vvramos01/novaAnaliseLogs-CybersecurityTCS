import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

    // classe com poo
    public static class LogEvent {
        private String timestamp;
        private String level;
        private String host;
        private String service;
        private String user;
        private String action;

        // construtor
        public LogEvent(String timestamp, String level, String host, String service, String user, String action) {
            this.timestamp = timestamp;
            this.level = level;
            this.host = host;
            this.service = service;
            this.user = user;
            this.action = action;
        }

        // getters simples
        public String getTimestamp() { return timestamp; }
        public String getLevel() { return level; }
        public String getHost() { return host; }
        public String getService() { return service; }
        public String getUser() { return user; }
        public String getAction() { return action; }
    }

    //extracao com regex
    private static LogEvent parseLine(String line) {
        String regex = "^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}) \\[(.*?)\\] \\[(.*?)\\] \\[(.*?)\\]: User (\\S+) (.*)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(line);

        if (matcher.find()) {
            return new LogEvent(
                    matcher.group(1), // timestamp
                    matcher.group(2), // level
                    matcher.group(3), // host
                    matcher.group(4), // service
                    matcher.group(5), // user
                    matcher.group(6)  // action
            );
        }
        // retorno
        return new LogEvent("N/A", "N/A", "N/A", "N/A", "N/A", "N/A");
    }

    // classificacao if else
    private static String classificarAmeaca(LogEvent log) {
        if (log.getService().equals("sshd") && log.getUser().equals("system_service")) {
            return "ALTO - N2: Conta de sistema realizando login interativo (sshd)";
        } else if (log.getUser().equals("backup_agent") && log.getService().equals("nginx")) {
            return "MÉDIO - N2: Agente de backup acessando servidor web (nginx)";
        } else {
            return "INFO - N1: Operação de rotina normal";
        }
    }

    public static void main(String[] args) {
        // amostra de logs simulando o arquivo
        List<String> linhasDeLogRaw = Arrays.asList(
                "2025-10-14 00:00:00 [INFO] [EST-CORP-028] [nginx]: User marcos.oliveira performed routine operation successfully",
                "2025-10-14 00:00:01 [INFO] [EST-CORP-034] [sshd]: User system_service performed routine operation successfully",
                "2025-10-14 00:00:04 [INFO] [EST-CORP-049] [sshd]: User backup_agent performed routine operation successfully",
                "2025-10-14 00:00:06 [INFO] [SRV-WEB-01] [syslog]: User marcos.oliveira performed routine operation successfully",
                "2025-10-14 00:00:10 [INFO] [EST-CORP-041] [nginx]: User backup_agent performed routine operation successfully",
                "2025-10-14 00:00:13 [INFO] [EST-CORP-022] [cron]: User marcos.oliveira performed routine operation successfully"
        );

        System.out.println("=== Iniciando analise de logs ===\n");

        // convertendo strings para objetos usando um for
        List<LogEvent> eventosProcessados = new ArrayList<>();
        for (int i = 0; i < linhasDeLogRaw.size(); i++) {
            String linha = linhasDeLogRaw.get(i);
            LogEvent eventoCriado = parseLine(linha);
            eventosProcessados.add(eventoCriado);
        }

        // processamento n1/n2 iterando a lista com for each e concatenando strings
        for (LogEvent evento : eventosProcessados) {
            String classificacao = classificarAmeaca(evento);
            System.out.println("[" + evento.getTimestamp() + "] Host: " + evento.getHost() +
                    " | Serviço: " + evento.getService() +
                    " | Usuario: " + evento.getUser() +
                    " | Classificaçao: " + classificacao);
        }

        System.out.println("\n=== Correlação de dados n3 ===");

        // modulo de correlacao n3 usando um hashmap e if else para contar as repeticoes
        Map<String, Integer> contagemAcessos = new HashMap<>();

        for (LogEvent evento : eventosProcessados) {
            String usuario = evento.getUser();

            // se o mapa ja tem o usuario soma 1, se não ele adiciona 1
            if (contagemAcessos.containsKey(usuario)) {
                int valorAtual = contagemAcessos.get(usuario);
                contagemAcessos.put(usuario, valorAtual + 1);
            } else {
                contagemAcessos.put(usuario, 1);
            }
        }

        // percorrendo o hasmap pra gerar os alertas
        for (String usuario : contagemAcessos.keySet()) {
            int totalDeAcoes = contagemAcessos.get(usuario);

            if (totalDeAcoes > 2) {
                System.out.println("Alerta de correlaçoa: O usuario '" + usuario + "' realizou " + totalDeAcoes + " operaçoes num curto periodo");
            }
        }
    }
}